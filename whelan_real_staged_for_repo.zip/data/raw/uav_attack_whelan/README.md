# Whelan UAV Attack Dataset — real Live GPS Spoofing and Jamming sample

Three real flights from the UAV Attack Dataset (Whelan et al., IEEE DataPort
10.21227/00dg-0d12), Live GPS Spoofing and Jamming subset, staged into the
layout ingest_whelan.py expects. Each flight: vehicle_gps_position (EKF-fused
GNSS solution) as gps.csv, vehicle_local_position as local.csv.

Platform: PX4 v1.11.3, Pixhawk 4, Holybro S500 (per dataset docs).
GPS columns: lat/lon are 1e-7 deg ints; jamming_indicator, noise_per_ms,
satellites_used, fix_type present.

## Measured signatures (this sample, self-referenced to pre-attack median)
- benign:   248 samples, 246 s, sats 11-13, fix=3 throughout (reference)
- jamming:  224 samples, 222 s, sats 14->4, fix 3->0 (lock loss), noise->171,
            peak pos_error 6.7 m, final-half mean 1.9 m
- spoofing: 138 samples, 136 s, fix held at 3 (FALSE lock), sats->5,
            peak pos_error 14.3 m, final-half mean 3.9 m

## Attack intervals (TODO - confirm from dataset docs before quoting)
The exact attack-on/off timestamps are NOT in these CSVs. For calibration this
sample self-references to the pre-attack window (first 25%). For paper numbers,
set the real intervals in whelan_manifest.json from the dataset documentation.

## IMPORTANT modeling note for the certificate
pos_error_m here is the NAVIGATION-FILTERED (EKF) error the controller acts on,
not the raw GPS error. PX4's estimator rejects bad GNSS, so raw error is larger.
Whether delta should be raw or filtered error is a certificate-semantics
decision - see docs/certified_regime_analysis.md. Do not silently pick one.
